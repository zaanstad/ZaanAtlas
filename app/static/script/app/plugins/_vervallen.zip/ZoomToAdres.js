/**
* Copyright (c) 2008-2011 The Open Planning Project
*
* Published under the GPL license.
* See https://github.com/opengeo/gxp/raw/master/license.txt for the full text
* of the license.
*/

/** api: (define)
* module = gxp.plugins
* class = ZoomToAdres
*/

/** api: (extends)
* plugins/Tool.js
*/
Ext.namespace("gxp.plugins");

/** api: constructor
* .. class:: ZoomToAdres(config)
*
* Plugin for removing a selected layer from the map.
* TODO Make this plural - selected layers
*/
gxp.plugins.ZoomToAdres = Ext.extend(gxp.plugins.Tool, {
    
/** api: ptype = gxp_zoomtoadres */
    ptype: "gxp_zoomtoadres",
    
/** api: config[addActionMenuText]
* ``String``
* Text for add menu item (i18n).
*/
    addActionMenuText: "Zoek adres",

/** api: config[addActionTip]
* ``String``
* Text for add action tooltip (i18n).
*/
    addActionTip: "Inzoomen naar een adres",

/** api: config[addLayerSourceErrorText]
* ``String``
* Text for an error message when WMS GetCapabilities retrieval fails (i18n).
*/
    addLayerSourceErrorText: "Error getting WMS capabilities ({msg}).\nPlease check the url and try again.",

/** api: config[availableLayersText]
* ``String``
* Text for the available layers (i18n).
*/
    availableLayersText: "Zoeken op adres of postcode",

/** api: config[availableLayersText]
* ``String``
* Text for the grid expander (i18n).
*/
    expanderTemplateText: "<p><b>Abstract:</b> {abstract}</p>",
    
/** api: config[availableLayersText]
* ``String``
* Text for the layer title (i18n).
*/
    panelTitleText: "Title",

/** api: config[availableLayersText]
* ``String``
* Text for the layer selection (i18n).
*/
    layerSelectionText: "View available data from:",
    
/** api: config[instructionsText]
* ``String``
* Text for additional instructions at the bottom of the grid (i18n).
* None by default.
*/
    
/** api: config[doneText]
* ``String``
* Text for Done button (i18n).
*/
    doneText: "Done",

/** api: config[upload]
* ``Object | Boolean``
* If provided, a :class:`gxp.LayerUploadPanel` will be made accessible
* from a button on the Available Layers dialog. This panel will be
* constructed using the provided config. By default, no upload
* functionality is provided.
*/
    
/** api: config[uploadText]
* ``String``
* Text for upload button (only renders if ``upload`` is provided).
*/
    menuText: "Zoek adres",

    /** private: method[constructor]
*/
    constructor: function(config) {
        gxp.plugins.ZoomToAdres.superclass.constructor.apply(this, arguments);
    },
    
/** api: method[addActions]
*/
    addActions: function() {
        var selectedLayer;
        var actions = gxp.plugins.ZoomToAdres.superclass.addActions.apply(this, [{
            tooltip : this.addActionTip,
            menuText: this.addActionMenuText,
            text: this.menuText,
            iconCls: "gxp-icon-find",
            handler : this.showCapabilitiesGrid,
            scope: this
        }]);
        
        this.target.on("ready", function() {
            actions[0].enable();
        });
        return actions;
    },
        
/** api: method[showCapabilitiesGrid]
* Shows the window with a capabilities grid.
*/
    showCapabilitiesGrid: function() {        
        this.initCapGrid();
        Tool_button = this.target.toolbar.items.items[17];
        Tool_button.disable();
    },

    /**
* private: method[initCapGrid]
* Constructs a window with a capabilities grid.
*/
    initCapGrid: function() {
        this.baseUrl =  window.location.host;
        this.baseUrl = "";
        //baseUrl = "http://10.205.17.5:8080";
	
        function trim(s)
        {
            return rtrim(ltrim(s));
        };

        function ltrim(s)
        {
            var l=0;
            while(l < s.length && s[l] == ' ')
            {
                l++;
            }
            return s.substring(l, s.length);
        };

        function rtrim(s)
        {
            var r=s.length -1;
            while(r > 0 && s[r] == ' ')
            {
                r-=1;
            }
            return s.substring(0, r+1);
        };		
        
        function getElementsByTag(doc, url, tag) {
            var urlArray = url.split( "/" );
            var ns = urlArray[urlArray.length-1];
            var value = doc.getElementsByTagName(ns + ":" +  tag);
            if(!value || value == null || value.length == 0){
                value = doc.getElementsByTagNameNS(url,  tag);
            }
            return value;
        };
        
        function Teken_symbool(objele, geoNs) {
        	
        	if (objele.length == 0) {
				
                alert('Dit adres bestaat niet');
            }	
            else {	
            	//alert(new XMLSerializer().serializeToString(objEle4[0]));
                var w = getElementsByTag(objele[0], geoNs, "vw_bag_adres");
							
                var m = getElementsByTag(w[0], geoNs, "geom900913");
                var x = getElementsByTag(w[0], geoNs, "x_coord");
                var y = getElementsByTag(w[0], geoNs, "y_coord");
							
                var xy900913 = m[0].childNodes[0].childNodes[0].childNodes[0].nodeValue;
                var komma = xy900913.indexOf(",");
                var x900913 = xy900913.substring(0,komma-1);
                var y900913 = xy900913.substring(komma+1);

                var lonlat = new OpenLayers.LonLat( x900913, y900913 );			
                var z = kaart.map;				
                z.setCenter(lonlat,18,false,false); 
															
                var punt = new OpenLayers.Geometry.Point();
                punt.x = x900913;
                punt.y = y900913;
							
                var feature = new OpenLayers.Feature.Vector();
                feature.fid = 1;
                feature.geometry = punt;
							
                var b = symboollayer1;
                var c = kaart.map;
							
                symboollayer1.removeAllFeatures();
                symboollayer1.addFeatures([feature]);
                symboollayer1.redraw();
            };				
        	
        	
        };
        
	
        var	 Zoek_adres = function() {	
        	var wfsNs = "http://www.opengis.net/wfs";
        	var gmlNs = "http://www.opengis.net/gml";
        	var geoNs = "http://www.zaanstad.nl/geo";
        
            var form = formulier;			
            var huisnummer = formulier.items.items[0].items.items[0].items.items[0].items.items[4].items.items[0].items.items[1] ;
            var straatnaam = formulier.items.items[0].items.items[0].items.items[0].items.items[3] ;
            var postcode = formulier.items.items[0].items.items[0].items.items[1].items.items[1] ;
            var huisletter = formulier.items.items[0].items.items[0].items.items[0].items.items[4].items.items[1].items.items[1] ;
            var plaats = formulier.items.items[0].items.items[0].items.items[0].items.items[1] ;
			
            if (straatnaam.selectedIndex > 0 && postcode.getValue() != '') {
                alert('Als u straatnaam heeft gekozen moet postcode leeg zijn !');
            }
            else if ((straatnaam.lastSelectionText == '' || straatnaam.selectedIndex == -1) && postcode.getValue() == '') {
                alert('U dient een straatnaam te selecteren of een postcode in te vullen');
            }		
            else if (huisnummer.getValue() == '') {
                alert('U dient een huisnummer in te vullen')
            }
            else if (postcode.getValue() == '') {
                //zoek op straatnaam, huisnummer en huisletter
                //roep geoserver-WFS aan met specifiek adres
                if (trim(huisletter.getValue()) == '') {	
                    var str_huisletter = " is null)";			
                }
                else {
					
                    var character = trim(huisletter.getValue());
					
                    if (character == character.toUpperCase()) {
                        characterUp = character;	
                        characterLow = character.toLowerCase();
                    };
                    if (character == character.toLowerCase()){
                        characterLow = character;						
                        characterUp = character.toUpperCase();						 
                    };
				
                    var str_huisletter = "='" + characterUp + "' OR huisletter='" + characterLow + "')";			
                };
				
                xhttp2 = new XMLHttpRequest();
                xhttp2.open("GET", 
                    "/geoserver/geo/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=geo:vw_bag_adres&cql_Filter"
                    +"=plaats='"                                 
                    + trim(plaats.lastSelectionText)                               
                    + "' AND straat='" 
                    + trim(straatnaam.lastSelectionText)                            
                    + "' AND huisnummer="                           
                    + trim(huisnummer.getValue())                            
                    + " AND (huisletter "                           
                    + str_huisletter,                      
                    false);
                xhttp2.send(null);
                var xmlDoc2=xhttp2.responseXML;

                var objEle3 =  getElementsByTag(xmlDoc2, wfsNs, "FeatureCollection");
                var objEle4 =  getElementsByTag(objEle3[0], gmlNs, "featureMember");
				
                Teken_symbool(objEle4,geoNs);
                							
            }
            else {				
                //zoek op postcode, huisnummer en toevoeging
                //roep geoserver-WFS aan met specifieke postcode	
                if (trim(postcode.getValue()).length > 6) {
                    alert("Geef postcode op in formaat 1234AB, dus zonder spaties");
                    return;
                };
				
                xhttp2 = new XMLHttpRequest();
                xhttp2.open("GET", 
                    "/geoserver/geo/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=geo:vw_bag_adres&cql_Filter=postcode='"
                    + trim(postcode.getValue()) 
                    + "' AND huisnummer=" 
                    + trim(huisnummer.getValue()), 
                    false);
                xhttp2.send(null);
                var xmlDoc2=xhttp2.responseXML;

                objEle3 =  getElementsByTag(xmlDoc2, wfsNs, "FeatureCollection");
                objEle4 =  getElementsByTag(objEle3[0], gmlNs, "featureMember");
				
                Teken_symbool(objEle4,geoNs);
            };					
        };
	
        var style =new OpenLayers.StyleMap({
			// Set the external graphic and background graphic images.
			externalGraphic: "theme/app/img/marker.png",
			backgroundGraphic: "theme/app/img/marker-shadow.png",
			
			// Makes sure the background graphic is placed correctly relative
			// to the external graphic.
			backgroundXOffset:  0,
			backgroundYOffset: -24,
			
			//graphicXOffset: -0.5,
			graphicYOffset: -27,
			
			// Set the z-indexes of both graphics to make sure the background
			// graphics stay in the background (shadows on top of markers looks
			// odd; let's not do that).
			graphicZIndex: 10,
			backgroundGraphicZIndex: 11,
            pointRadius: 15,
        });
		
        symboollayer1 = new OpenLayers.Layer.Vector("Adres", {styleMap: style, displayInLayerSwitcher: false});	
        //symboollayer1.opacity = 0.5;	
        kaart = this.target.mapPanel;
        var kaart1 = this.target.mapPanel;
        kaart.map.addLayers([symboollayer1]);
		var kaartposition = kaart.getPosition();
		var kaartsize = kaart.getSize();
		
        request2 = new XMLHttpRequest();
        request2.open(	"GET", 
        				"/geoserver/geo/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=geo:unieke_plaats&outputFormat=json", 
        				true);

        //request.setRequestHeader ("Content-Type", "text/xml"); 	
        request2.onreadystatechange = function (aEvt) {  
		
            if (request2.readyState == 4) {  
                if (request2.status == 200) {
                    var my_JSON_object2 = {};
                    my_JSON_object2 = JSON.parse(request2.responseText);
		
                    var jstore2 = new Ext.data.JsonStore({
                        root: 'features',
                        fields: [ 'id', {
                            name:'plaats', 
                            mapping:'properties.plaats'
                        } ],
                        autoLoad: true,
                        data: my_JSON_object2
                    });
				
                    var lege_store = new Ext.data.JsonStore({
                        root: 'features',
                        fields: [ 'id', 'straat'],
                        autoLoad: true,
                        data: {
                            features:[{
                                'id':'',
                                'straat':''
                            }]
                            }
                    });
				
                    var items1 = [{ 
                        xtype: 'container',
                        anchor: '100%',
                        layout:'column',
                        items:[{
                            xtype: 'container',
                            columnWidth:.7,
                            layout: 'anchor',
                            items: [
						
                            {
                                xtype:'label',
                                text: "Kies een plaatsnaam",
                                width: 300
                            },

                            {
                                xtype:'combo',
                                //fieldLabel: 'Kies een straatnaam',
                                name: 'plaats',
                                anchor:'96%',
                                store: jstore2,
                                valueField: 'id',
                                displayField: 'plaats',
                                width: 300,
                                height: 60,
                                //triggerAction: "all",
                                //editable: false,
                                disabled: false,
                                hidden: false,
                                //allowBlank: false,
                                //forceSelection: true,
                                mode: "local",
                                //value: data[idx][0]  /**,
                                listeners: {
                                    select: function(combo, record, index) {											
                                        var request = new XMLHttpRequest();
                                        request.open("GET", 
                                            "/geoserver/geo/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=" 
                                            + "geo:unieke_straat&cql_Filter=plaats='" 
                                            + record.get("plaats") 
                                            + "'&outputFormat=json", 
                                            true);	
										
                                        request.onreadystatechange = function (aEvt) {  
                                            if (request.readyState == 4) {  
                                                if (request.status == 200) {
                                                    var my_JSON_object = {};
                                                    my_JSON_object = JSON.parse(request.responseText);

                                                    var jstore = new Ext.data.JsonStore({
                                                        root: 'features',
                                                        fields: [ 'id', {
                                                            name:'straat', 
                                                            mapping:'properties.straat'
                                                        } ],
                                                        //autoLoad: true,
                                                        data: my_JSON_object
                                                    });
                                                    var form = formulier;	
                                                    formulier.items.items[0].items.items[0].items.items[0].items.items[3].bindStore(jstore,true);
                                                };
                                            }
                                        };

                                    request.send(null);
                                },
                                scope: this
                            }
                        },

                        {
                        xtype:'label',
                        text: "en een straatnaam",
                        width: 300
                    },

                    {
                        xtype:'combo',
                        //fieldLabel: 'Kies een straatnaam',
                        name: 'straat',
                        anchor:'96%',
                        store: lege_store,
                        valueField: 'id',
                        displayField: 'straat',
                        width: 300,
                        height: 60,
                        //triggerAction: "all",
                        //editable: false,
                        disabled: false,
                        hidden: false,
                        //allowBlank: false,
                        //forceSelection: true,
                        mode: "local",
                        //value: data[idx][0]  /**,
                        listeners: {
                            select: function(combo, record, index) {
                            },
                            scope: this
                        }
                    },

                    { 
                    xtype: 'container',
                    anchor: '100%',
                    layout:'column',
                    items:[
                    {
                        xtype: 'container',
                        columnWidth:.5,
                        layout: 'anchor',
                        items:[
                        {
                            xtype:'label',
                            text: "huisnummer",
                            width: 100,
                            anchor: '100%'
                        },

                        {
                            xtype:'textfield',
                            name:'huisnummer',
                            width: 50,
                            anchor: '100%'
                        }]
                        },

                        {
                        xtype: 'container',
                        columnWidth:.5,
                        layout: 'anchor',
                        items:[
                        {
                            xtype:'label',
                            text: "huisletter",
                            width: 100,
                            anchor: '100%'
                        },

                        {
                            xtype:'textfield',
                            name:'huisletter',
                            width: 50,
                            anchor:'100%'
                        }]
                        },
                    ]
                    },{
                    buttons:[{
                        text:"Zoek adres", 
                        handler: Zoek_adres, 
                        scope:this
                    }]
                    }]
            },{
                xtype: 'container',
                columnWidth:.3,
                layout: 'anchor',
                items: [{
                    xtype:'label',
                    text: "of vul in een postcode",
                    width: 300
                },

                {
                    xtype:'textfield',
                    name:'postcode',
                    width: 50
                }
                ]
            }]
            }];
	
        var items = [{
            xtype: "container",
            region: "center",
            //layout: "vbox",
            items: items1 
        }];
	
			
        this.capGrid = new Ext.Window({
            title: "Zoeken op adres",
            //fieldDefaults: {labelAlign: 'top'},
            bodyStyle:'padding:5px 5px 0',
            closeAction: "close",
            layout: "border",
            height: 180,
            width: 370,
            x: kaartposition[0] + kaartsize.width - 370,
            y: kaartposition[1],
            //maxWidth: 600,
            //maxHeight: 150,
            //modal: true,
            resizable: false, 
            items: items,
            listeners: {
                destroy: function(win) {
                    Tool_button.enable();
                    var aantal = kaart.map.layers.length;
                    for(var p = 0; p < aantal; p++) {
                        if (kaart.map.layers[p].name == "Adres") { 
                            //map.layers[p].destroy();
                            kaart.map.removeLayer(kaart.map.layers[p]);
                        };	
                    };
                }//,
            //scope: this
            }
        });

        this.capGrid.show();
        formulier = this.capGrid;    	
    };		 
}
};		
request2.send(null);       	
} 	
});
Ext.preg(gxp.plugins.ZoomToAdres.prototype.ptype, gxp.plugins.ZoomToAdres);